var json_Erroroutput_3 = {
"type": "FeatureCollection",
"name": "Erroroutput_3",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "message": "line 1 contains 2 duplicate nodes starting at vertex 2" }, "geometry": { "type": "Point", "coordinates": [ 147.742939175524185, -6.602952092433683 ] } },
{ "type": "Feature", "properties": { "message": "line 1 contains 2 duplicate nodes starting at vertex 9" }, "geometry": { "type": "Point", "coordinates": [ 147.734400316584185, -6.601742079638863 ] } },
{ "type": "Feature", "properties": { "message": "line 1 contains 2 duplicate nodes starting at vertex 1" }, "geometry": { "type": "Point", "coordinates": [ 147.725319426600436, -6.596706246533111 ] } },
{ "type": "Feature", "properties": { "message": "line 1 contains 2 duplicate nodes starting at vertex 13" }, "geometry": { "type": "Point", "coordinates": [ 147.721028643341015, -6.596612875826258 ] } },
{ "type": "Feature", "properties": { "message": "line 1 contains 2 duplicate nodes starting at vertex 1" }, "geometry": { "type": "Point", "coordinates": [ 147.721807437388037, -6.596309403236044 ] } },
{ "type": "Feature", "properties": { "message": "line 1 contains 2 duplicate nodes starting at vertex 2" }, "geometry": { "type": "Point", "coordinates": [ 147.713880564733557, -6.596269175182279 ] } },
{ "type": "Feature", "properties": { "message": "line 1 contains 2 duplicate nodes starting at vertex 9" }, "geometry": { "type": "Point", "coordinates": [ 147.700908725473596, -6.586916820561568 ] } },
{ "type": "Feature", "properties": { "message": "line 1 contains 2 duplicate nodes starting at vertex 1" }, "geometry": { "type": "Point", "coordinates": [ 147.700847464305838, -6.586772980111299 ] } },
{ "type": "Feature", "properties": { "message": "line 1 contains 2 duplicate nodes starting at vertex 3" }, "geometry": { "type": "Point", "coordinates": [ 147.704272606031992, -6.583101725138233 ] } }
]
}
