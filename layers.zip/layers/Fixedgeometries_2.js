var json_Fixedgeometries_2 = {
"type": "FeatureCollection",
"name": "Fixedgeometries_2",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [

]
}
