var wms_layers = [];


        var lyr_GoogleHybrid_0 = new ol.layer.Tile({
            'title': 'Google Hybrid',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: '<a href="https://www.google.at/permissions/geoguidelines/attr-guide.html">Map data ©2015 Google</a>',
                url: 'https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}'
            })
        });

        var lyr_GoogleSatellite_1 = new ol.layer.Tile({
            'title': 'Google Satellite',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: '<a href="https://www.google.at/permissions/geoguidelines/attr-guide.html">Map data ©2015 Google</a>',
                url: 'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}'
            })
        });
var format_Fixedgeometries_2 = new ol.format.GeoJSON();
var features_Fixedgeometries_2 = format_Fixedgeometries_2.readFeatures(json_Fixedgeometries_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Fixedgeometries_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Fixedgeometries_2.addFeatures(features_Fixedgeometries_2);
var lyr_Fixedgeometries_2 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Fixedgeometries_2, 
                style: style_Fixedgeometries_2,
                popuplayertitle: 'Fixed geometries',
                interactive: true,
                title: '<img src="styles/legend/Fixedgeometries_2.png" /> Fixed geometries'
            });
var format_Erroroutput_3 = new ol.format.GeoJSON();
var features_Erroroutput_3 = format_Erroroutput_3.readFeatures(json_Erroroutput_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Erroroutput_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Erroroutput_3.addFeatures(features_Erroroutput_3);
var lyr_Erroroutput_3 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Erroroutput_3, 
                style: style_Erroroutput_3,
                popuplayertitle: 'Error output',
                interactive: true,
                title: '<img src="styles/legend/Erroroutput_3.png" /> Error output'
            });
var format_Erroroutput_4 = new ol.format.GeoJSON();
var features_Erroroutput_4 = format_Erroroutput_4.readFeatures(json_Erroroutput_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Erroroutput_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Erroroutput_4.addFeatures(features_Erroroutput_4);
var lyr_Erroroutput_4 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Erroroutput_4, 
                style: style_Erroroutput_4,
                popuplayertitle: 'Error output',
                interactive: true,
                title: '<img src="styles/legend/Erroroutput_4.png" /> Error output'
            });
var format_InundationRiskZones_5 = new ol.format.GeoJSON();
var features_InundationRiskZones_5 = format_InundationRiskZones_5.readFeatures(json_InundationRiskZones_5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_InundationRiskZones_5 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_InundationRiskZones_5.addFeatures(features_InundationRiskZones_5);
var lyr_InundationRiskZones_5 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_InundationRiskZones_5, 
                style: style_InundationRiskZones_5,
                popuplayertitle: 'Inundation Risk Zones',
                interactive: true,
                title: '<img src="styles/legend/InundationRiskZones_5.png" /> Inundation Risk Zones'
            });
var format_RiversandCreeks_6 = new ol.format.GeoJSON();
var features_RiversandCreeks_6 = format_RiversandCreeks_6.readFeatures(json_RiversandCreeks_6, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_RiversandCreeks_6 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_RiversandCreeks_6.addFeatures(features_RiversandCreeks_6);
var lyr_RiversandCreeks_6 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_RiversandCreeks_6, 
                style: style_RiversandCreeks_6,
                popuplayertitle: 'Rivers and Creeks',
                interactive: true,
                title: '<img src="styles/legend/RiversandCreeks_6.png" /> Rivers and Creeks'
            });
var format_Culverts_7 = new ol.format.GeoJSON();
var features_Culverts_7 = format_Culverts_7.readFeatures(json_Culverts_7, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Culverts_7 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Culverts_7.addFeatures(features_Culverts_7);
var lyr_Culverts_7 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Culverts_7, 
                style: style_Culverts_7,
                popuplayertitle: 'Culverts',
                interactive: true,
                title: '<img src="styles/legend/Culverts_7.png" /> Culverts'
            });
var format_stream_outlets_8 = new ol.format.GeoJSON();
var features_stream_outlets_8 = format_stream_outlets_8.readFeatures(json_stream_outlets_8, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_stream_outlets_8 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_stream_outlets_8.addFeatures(features_stream_outlets_8);
var lyr_stream_outlets_8 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_stream_outlets_8, 
                style: style_stream_outlets_8,
                popuplayertitle: 'stream_outlets',
                interactive: true,
                title: '<img src="styles/legend/stream_outlets_8.png" /> stream_outlets'
            });
var format_GradientSlope_9 = new ol.format.GeoJSON();
var features_GradientSlope_9 = format_GradientSlope_9.readFeatures(json_GradientSlope_9, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_GradientSlope_9 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_GradientSlope_9.addFeatures(features_GradientSlope_9);
var lyr_GradientSlope_9 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_GradientSlope_9, 
                style: style_GradientSlope_9,
                popuplayertitle: 'Gradient Slope',
                interactive: true,
                title: '<img src="styles/legend/GradientSlope_9.png" /> Gradient Slope'
            });
var format_ChainagePoints_10 = new ol.format.GeoJSON();
var features_ChainagePoints_10 = format_ChainagePoints_10.readFeatures(json_ChainagePoints_10, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_ChainagePoints_10 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_ChainagePoints_10.addFeatures(features_ChainagePoints_10);
var lyr_ChainagePoints_10 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_ChainagePoints_10, 
                style: style_ChainagePoints_10,
                popuplayertitle: 'Chainage Points',
                interactive: true,
                title: '<img src="styles/legend/ChainagePoints_10.png" /> Chainage Points'
            });
var format_Road_centerline_11 = new ol.format.GeoJSON();
var features_Road_centerline_11 = format_Road_centerline_11.readFeatures(json_Road_centerline_11, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Road_centerline_11 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Road_centerline_11.addFeatures(features_Road_centerline_11);
var lyr_Road_centerline_11 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Road_centerline_11, 
                style: style_Road_centerline_11,
                popuplayertitle: 'Road_centerline',
                interactive: true,
                title: '<img src="styles/legend/Road_centerline_11.png" /> Road_centerline'
            });
var group_02_WEBREADYOUTPUT = new ol.layer.Group({
                                layers: [lyr_Fixedgeometries_2,lyr_Erroroutput_3,lyr_Erroroutput_4,lyr_InundationRiskZones_5,lyr_RiversandCreeks_6,lyr_Culverts_7,lyr_stream_outlets_8,lyr_GradientSlope_9,lyr_ChainagePoints_10,lyr_Road_centerline_11,],
                                fold: 'open',
                                title: '02_WEB READY OUTPUT'});
var group_ValidityChecks = new ol.layer.Group({
                                layers: [],
                                fold: 'close',
                                title: 'Validity Checks'});
var group_FixedGeometries = new ol.layer.Group({
                                layers: [],
                                fold: 'open',
                                title: 'Fixed Geometries'});
var group_group2 = new ol.layer.Group({
                                layers: [],
                                fold: 'open',
                                title: 'group2'});
var group_01_DataSource = new ol.layer.Group({
                                layers: [],
                                fold: 'open',
                                title: '01_DataSource'});

lyr_GoogleHybrid_0.setVisible(true);lyr_GoogleSatellite_1.setVisible(true);lyr_Fixedgeometries_2.setVisible(true);lyr_Erroroutput_3.setVisible(true);lyr_Erroroutput_4.setVisible(true);lyr_InundationRiskZones_5.setVisible(true);lyr_RiversandCreeks_6.setVisible(true);lyr_Culverts_7.setVisible(true);lyr_stream_outlets_8.setVisible(true);lyr_GradientSlope_9.setVisible(true);lyr_ChainagePoints_10.setVisible(true);lyr_Road_centerline_11.setVisible(true);
var layersList = [lyr_GoogleHybrid_0,lyr_GoogleSatellite_1,group_02_WEBREADYOUTPUT];
lyr_Fixedgeometries_2.set('fieldAliases', {'fid': 'fid', 'culvert_id': 'culvert_id', 'structure': 'structure', 'length_m': 'length_m', 'diameter_m': 'diameter_m', 'condition': 'condition', 'function': 'function', 'recommendation': 'recommendation', 'source_condition': 'source_condition', 'data_note': 'data_note', '_errors': '_errors', });
lyr_Erroroutput_3.set('fieldAliases', {'message': 'message', });
lyr_Erroroutput_4.set('fieldAliases', {'message': 'message', });
lyr_InundationRiskZones_5.set('fieldAliases', {'fid': 'fid', 'risk_zone_id ': 'Risk Zone ID', 'risk_level': 'Inundation Risk', 'risk_rank ': 'risk_rank ', 'source_description': 'source_description', });
lyr_RiversandCreeks_6.set('fieldAliases', {'fid': 'fid', 'waterway_id ': 'Waterway ID', 'waterway_type': 'Waterway Type', });
lyr_Culverts_7.set('fieldAliases', {'fid': 'fid', 'culvert_id': 'Culvert ID', 'structure': 'Culvert Type', 'length_m': 'Culvert Length (m)', 'diameter_m': 'Diameter (m)', 'condition': 'Condition', 'function': 'Function', 'recommendation': 'Recommended Action', 'source_condition': 'source_condition', 'data_note': 'Verification Note', });
lyr_stream_outlets_8.set('fieldAliases', {'fid': 'fid', 'outlet_id': 'Outlet ID', 'waterway_name': 'Waterway', 'flow_status': 'Flow Status', });
lyr_GradientSlope_9.set('fieldAliases', {'fid': 'fid', 'segment_id': 'Segment ID', 'gradient_pct': 'Gradient (%)', 'terrain_class': 'Terrain Class', 'chainage': 'Chainage', 'segment_length_m': 'Segment Length (m)', 'source_gradient': 'source_gradient', 'source_category': 'source_category', });
lyr_ChainagePoints_10.set('fieldAliases', {'fid': 'fid', 'chainage_id ': 'Chainage ID', 'chainage': 'Chainage', 'elevation_m': 'Elevation (m)', 'easting': 'Easting (m)', 'northing': 'Northing (m)', });
lyr_Road_centerline_11.set('fieldAliases', {'fid': 'fid', 'road_id': 'road_id', 'feature_type': 'feature_type', 'length_m': 'length_m', });
lyr_Fixedgeometries_2.set('fieldImages', {'fid': '', 'culvert_id': '', 'structure': '', 'length_m': '', 'diameter_m': '', 'condition': '', 'function': '', 'recommendation': '', 'source_condition': '', 'data_note': '', '_errors': '', });
lyr_Erroroutput_3.set('fieldImages', {'message': '', });
lyr_Erroroutput_4.set('fieldImages', {'message': '', });
lyr_InundationRiskZones_5.set('fieldImages', {'fid': 'Hidden', 'risk_zone_id ': 'TextEdit', 'risk_level': 'TextEdit', 'risk_rank ': 'Hidden', 'source_description': 'Hidden', });
lyr_RiversandCreeks_6.set('fieldImages', {'fid': 'Hidden', 'waterway_id ': 'TextEdit', 'waterway_type': 'TextEdit', });
lyr_Culverts_7.set('fieldImages', {'fid': 'Hidden', 'culvert_id': 'TextEdit', 'structure': 'TextEdit', 'length_m': 'TextEdit', 'diameter_m': 'TextEdit', 'condition': 'TextEdit', 'function': 'TextEdit', 'recommendation': 'TextEdit', 'source_condition': 'Hidden', 'data_note': 'TextEdit', });
lyr_stream_outlets_8.set('fieldImages', {'fid': 'Hidden', 'outlet_id': 'TextEdit', 'waterway_name': 'TextEdit', 'flow_status': 'TextEdit', });
lyr_GradientSlope_9.set('fieldImages', {'fid': 'Hidden', 'segment_id': 'TextEdit', 'gradient_pct': 'TextEdit', 'terrain_class': 'TextEdit', 'chainage': 'TextEdit', 'segment_length_m': 'TextEdit', 'source_gradient': 'Hidden', 'source_category': 'Hidden', });
lyr_ChainagePoints_10.set('fieldImages', {'fid': 'TextEdit', 'chainage_id ': 'TextEdit', 'chainage': 'TextEdit', 'elevation_m': 'TextEdit', 'easting': 'Hidden', 'northing': 'Hidden', });
lyr_Road_centerline_11.set('fieldImages', {'fid': 'TextEdit', 'road_id': 'TextEdit', 'feature_type': 'TextEdit', 'length_m': 'TextEdit', });
lyr_Fixedgeometries_2.set('fieldLabels', {'fid': 'no label', 'culvert_id': 'no label', 'structure': 'no label', 'length_m': 'no label', 'diameter_m': 'no label', 'condition': 'no label', 'function': 'no label', 'recommendation': 'no label', 'source_condition': 'no label', 'data_note': 'no label', '_errors': 'no label', });
lyr_Erroroutput_3.set('fieldLabels', {'message': 'no label', });
lyr_Erroroutput_4.set('fieldLabels', {'message': 'no label', });
lyr_InundationRiskZones_5.set('fieldLabels', {'risk_zone_id ': 'no label', 'risk_level': 'no label', });
lyr_RiversandCreeks_6.set('fieldLabels', {'waterway_id ': 'no label', 'waterway_type': 'no label', });
lyr_Culverts_7.set('fieldLabels', {'culvert_id': 'no label', 'structure': 'no label', 'length_m': 'no label', 'diameter_m': 'no label', 'condition': 'no label', 'function': 'no label', 'recommendation': 'no label', 'data_note': 'no label', });
lyr_stream_outlets_8.set('fieldLabels', {'outlet_id': 'no label', 'waterway_name': 'no label', 'flow_status': 'no label', });
lyr_GradientSlope_9.set('fieldLabels', {'segment_id': 'no label', 'gradient_pct': 'no label', 'terrain_class': 'no label', 'chainage': 'no label', 'segment_length_m': 'no label', });
lyr_ChainagePoints_10.set('fieldLabels', {'fid': 'no label', 'chainage_id ': 'no label', 'chainage': 'no label', 'elevation_m': 'no label', });
lyr_Road_centerline_11.set('fieldLabels', {'fid': 'no label', 'road_id': 'no label', 'feature_type': 'no label', 'length_m': 'no label', });
lyr_Road_centerline_11.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});